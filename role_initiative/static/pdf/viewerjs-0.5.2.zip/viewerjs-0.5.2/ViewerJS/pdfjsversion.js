var /**@const{!string}*/pdfjs_version = "d45d7bc";
